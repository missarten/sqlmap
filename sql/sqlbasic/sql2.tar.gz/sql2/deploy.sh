sudo apt-get -y install apache2 mysql-server php5 php5-mysql php-pear php5-gd
sudo mv sql2/ /var/www/html/
sudo chmod 777 /var/www/html/sql2 
sudo service mysql start
sudo service apache2 start

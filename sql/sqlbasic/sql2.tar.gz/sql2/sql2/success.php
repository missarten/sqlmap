<title>登陆成功</title>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
</head>

<body >
恭喜你登陆成功<br>
<tr><a href="index.html"><input type="button" value="返回首页"></input></a></tr>
<form action="validate.php" method="post">
  <fieldset >


</body>
</html>
